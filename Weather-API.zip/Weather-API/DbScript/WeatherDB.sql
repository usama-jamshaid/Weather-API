CREATE TABLE `weather` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`is_valid` INT(11) NOT NULL,
	`latitude` DOUBLE NULL DEFAULT '0',
	`longitude` DOUBLE NULL DEFAULT '0',
	`icon` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
	`location` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
	`is_open_weather` TINYINT(4) NULL DEFAULT NULL,
	`temperature` DOUBLE NULL DEFAULT NULL,
	`date_time` DATETIME NULL DEFAULT NULL,
	PRIMARY KEY (`id`) USING BTREE
)
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=1
;
