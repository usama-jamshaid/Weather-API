﻿using System;
using System.Collections.Generic;
using System.Text;
using Weather.Abstractions;
using Weather.Data.DbEntities;

namespace Weather.Data.DataAccessObjects
{
    public class WeatherRespository : BaseRepository<DbEntities.WeatherDTO>, IWeatherRepository
    {
        public WeatherRespository(WeatherDbContext dbContext) : base(dbContext)
        {
        }
    }
}
