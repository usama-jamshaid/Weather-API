﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.Abstractions;
using Weather.Data.DbEntities;
using Weather.Models;

namespace Weather_API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class WeatherController : ControllerBase
    {
        IWeatherService _weatherService;
        public WeatherController(IWeatherService weatherService)
        {
            _weatherService = weatherService;
        }
        [HttpGet]
        public ResponseBase GetWeatherData(
            [FromQuery]int start, 
            [FromQuery] int count, 
            [FromQuery] string location, 
            [FromQuery] bool isOpenWeather = false)
        {
            var request = new GetWeatherRequest
            {
                Start = start,
                Count = count,
                Location = location,
                IsOpenWeather = isOpenWeather
            };
            var data = _weatherService.GetWeatherData(request);
            return ResponseModel<List<WeatherDTO>>.GetSuccess(data);
        }
        [HttpPost]
        public ResponseBase AddJson(List<WeatherDTO> list)
        {
            _weatherService.AddRange(list);
            return ResponseBase.GetSuccess();
        }
        [HttpGet]
        public ResponseBase DumpFromOpenWeather([FromQuery] string location)
        {
            _weatherService.SaveForecastfromOW(location);
            return ResponseBase.GetSuccess();
        }
    }
}
