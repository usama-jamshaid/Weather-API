﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.Abstractions;
using Weather.Models;

namespace Weather_API
{
    [Route("api/[Controller]/[Action]")]
    public class AuthController : ControllerBase
    {
        private ITokenService _tokenService;
        public AuthController(ITokenService tokenService)
        {
            _tokenService = tokenService;
        }
        [HttpGet]
        public ResponseBase Get ([FromQuery]string username,[FromQuery] string password)
        {
            var token = _tokenService.GenerateToken(username, password);
            return ResponseModel<string>.GetSuccess(token);
        }
    }
}
