﻿using Common.RequestResponseModels;
using Microsoft.Extensions.Configuration;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Text;
using Weather.Abstractions;
using Weather.Models;

namespace Weather.Services
{
    public class OpenWeatherService : IOpenWeatherService
    {
        IConfiguration Configuration;
        public OpenWeatherService (IConfiguration config)
        {
            Configuration = config;
        }

        public OWForecastResponse GetWeatherForecast(double longitude, double latitude)
        {
            var client = new RestClient(Configuration["OpenWeather:WeatherBaseUrl"]);
            var request = new RestRequest("/forecast");
            request.AddQueryParameter("lat", latitude);
            request.AddQueryParameter("lon", longitude);
            request.AddQueryParameter("appid", Configuration["OpenWeather:ApiKey"]);
            var response =   client.GetAsync<OWForecastResponse>(request).GetAwaiter().GetResult();
            return response; 
        }
        public List<OWGetCoordinatesResponse> GetCoordinates(string place)
        {
            var client = new RestClient(Configuration["OpenWeather:LocationBaseUrl"]);
            var request = new RestRequest("/direct");
            request.AddQueryParameter("q", place);
            request.AddQueryParameter("limit", 1);
            request.AddQueryParameter("appid", Configuration["OpenWeather:ApiKey"]);
            var response = client.GetAsync<List<OWGetCoordinatesResponse>>(request).GetAwaiter().GetResult();
            return response;
        }
    }
}
