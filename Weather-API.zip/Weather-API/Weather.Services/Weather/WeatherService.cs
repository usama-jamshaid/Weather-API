﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Weather.Abstractions;
using Weather.Data.DbEntities;
using Weather.Models;

namespace Weather.Services
{
    public class WeatherService : BaseService<Data.DbEntities.WeatherDTO>, IWeatherService
    {
        IOpenWeatherService _openWeatherService;
        public WeatherService(IWeatherRepository baseRepository, IOpenWeatherService openWeatherService) : base(baseRepository)
        {
            _openWeatherService = openWeatherService;
        }

        public List<WeatherDTO> GetWeatherData(GetWeatherRequest request)
        {
            //Calls the method of base class
            var data = GetByCondition(x => x.IsOpenWeather == request.IsOpenWeather);

            //Apply relevant filters
            if (!string.IsNullOrEmpty(request.Location))
                data = data.Where(x => x.Location == request.Location);
            if (request.Start > 0 && request.Count > 0)
                data = data.Skip(request.Start).Take(request.Count);
            return data.ToList();
        }
        public void SaveForecastfromOW(string place)
        {
            // Get location coordinates
            var coordinates = _openWeatherService.GetCoordinates(place).FirstOrDefault();

            if (coordinates == null)
                throw new Exception("Sorry! We couldn't find the specified location");
            // Get weather forecast
            var weatherForest = _openWeatherService.GetWeatherForecast(coordinates.lon, coordinates.lat);
            //Map to local DTO
            var mappedList = weatherForest.list.ToList().Select(x => new WeatherDTO
            {
                Temperature = x.main.temp,
                DateTime = DateTimeOffset.FromUnixTimeSeconds(x.dt).DateTime,
                Icon = x.weather.FirstOrDefault()?.icon,
                IsOpenWeather = true,
                IsValid = true,
                Latitude = coordinates.lat,
                Longitude = coordinates.lon,
                Location = place
            }).ToList();

            //Check duplicates
            var existingRecords = GetByCondition(x => x.Longitude == coordinates.lon && x.Latitude == coordinates.lat
             && x.DateTime >= mappedList.First().DateTime && x.DateTime <= mappedList.Last().DateTime && x.IsOpenWeather == true).ToList();
            //Filter duplicates
            mappedList = mappedList.Except(existingRecords, new WeatherComparer()).ToList();

            if (mappedList.Count > 0)
                AddRange(mappedList);
        }
    }
}
