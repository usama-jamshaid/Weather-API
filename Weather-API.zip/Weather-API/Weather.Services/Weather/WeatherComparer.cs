﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using Weather.Data.DbEntities;

namespace Weather.Services
{
    public class WeatherComparer : IEqualityComparer<WeatherDTO>
    {
        public bool Equals([AllowNull] WeatherDTO x, [AllowNull] WeatherDTO y)
        {
            return x.IsOpenWeather == y.IsOpenWeather &&
                x.Longitude == y.Longitude &&
                x.Latitude == y.Latitude &&
                x.DateTime == y.DateTime;
        }

        public int GetHashCode([DisallowNull] WeatherDTO obj)
        {
            return obj.Longitude.GetHashCode()^
                obj.Latitude.GetHashCode()^
                obj.DateTime.GetHashCode();
        }
    }
}
