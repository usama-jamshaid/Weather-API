﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using Weather.Abstractions;

namespace Weather.Services
{
    public class AuthService : IAuthService
    {
        private IConfiguration _config;
        public AuthService(IConfiguration config)
        {
            _config = config;
        }
        public bool IsUserAutheticated(string username, string password = null)
        {
            if (username == _config["Jwt:AllowedUser"])
                return true;
            else
                return false;
        }
    }
}
