﻿using Common.RequestResponseModels;
using System;
using System.Collections.Generic;
using System.Text;
using Weather.Models;

namespace Weather.Abstractions
{
    public interface IOpenWeatherService
    {
        OWForecastResponse GetWeatherForecast(double longitude, double latitude);
        List<OWGetCoordinatesResponse> GetCoordinates(string place);
    }
}
