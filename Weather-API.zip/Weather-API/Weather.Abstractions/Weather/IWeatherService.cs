﻿using System;
using System.Collections.Generic;
using System.Text;
using Weather.Data.DbEntities;
using Weather.Models;

namespace Weather.Abstractions
{
    public interface IWeatherService : IBaseService<Data.DbEntities.WeatherDTO>
    {
        List<WeatherDTO> GetWeatherData(GetWeatherRequest request);
        void SaveForecastfromOW(string place);
    }
}
