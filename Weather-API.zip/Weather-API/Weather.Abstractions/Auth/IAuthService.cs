﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Weather.Abstractions
{
    public interface IAuthService
    {
        bool IsUserAutheticated(string username, string password);
    }
}
