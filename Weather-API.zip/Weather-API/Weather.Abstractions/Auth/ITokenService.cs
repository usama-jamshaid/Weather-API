﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Weather.Abstractions
{
    public interface ITokenService
    {
        string GenerateToken(string username, string password);
    }
}
