﻿using System;
using Weather.Data.DbEntities;

namespace Weather.Abstractions
{
    public interface IWeatherRepository : IBaseRepository<Data.DbEntities.WeatherDTO>
    {
    }
}
