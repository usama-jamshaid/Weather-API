# Weather-API

**Instructions**

Use MYSQL as database
Please find the sql in DBScripts/WeatherDB 

**Best practices used in the project**

- Implemented repository design pattern
- Integrated swagger UI to documentation
- Added global exception handling
- Implemented JWT for security