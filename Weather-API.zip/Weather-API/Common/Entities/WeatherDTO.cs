﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using Weather.Models;

namespace Weather.Data.DbEntities
{
    [Table("weather")]
    public class WeatherDTO : BaseEntity
    {
        [Column("date_time")]
        public DateTime DateTime { get; set; }
        [Column("location")]
        public string Location { get; set; }
        [Column("longitude")]
        public double Longitude { get; set; }
        [Column("latitude")]
        public double Latitude { get; set; }
        [Column("temperature")]
        public double Temperature { get; set; }
        [Column("is_open_weather")]
        public bool IsOpenWeather { get; set; }
        [Column("icon")]
        public string Icon { get; set; }
    }
}
