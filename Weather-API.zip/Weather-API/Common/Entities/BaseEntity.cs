﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Weather.Models
{
    public class BaseEntity
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("is_valid")]
        public bool IsValid { get; set; }
    }
}
