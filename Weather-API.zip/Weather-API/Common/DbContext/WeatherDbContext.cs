﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Weather.Data.DbEntities;

namespace Weather.Data.DataAccessObjects
{
    public class WeatherDbContext : DbContext
    { 
        public virtual DbSet<WeatherDTO> Weather { get; set; }
        public WeatherDbContext(DbContextOptions<WeatherDbContext> options)
            : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                throw new Exception("Db is not configured");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DbEntities.WeatherDTO>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.IsValid);
                entity.Property(e => e.DateTime);
                entity.Property(e => e.IsOpenWeather);             
            });
        }
    }
}
