﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using Weather.Abstractions;
using Weather.Models;

namespace Weather.Data.DataAccessObjects
{
    //Base repository class with some major CRUDs operation
    public class BaseRepository<T> : IBaseRepository<T> where T : BaseEntity
    {
        readonly WeatherDbContext _dbContext;
        readonly DbSet<T> _dataSet;

        public BaseRepository (WeatherDbContext dbContext)
        {
            _dbContext = dbContext;
            _dataSet = _dbContext.Set<T>();
        }
        public virtual void Add(T entity)
        {
            _dataSet.Add(entity);
            SaveChanges();
        }

        public virtual void Delete(int id)
        {
            var entity = Get(id);
            entity.IsValid = false;
            SaveChanges();
        }

        public virtual T Get(int Id)
        {
            return _dataSet.FirstOrDefault(x => x.Id == Id);
        }

        public virtual IQueryable<T> GetByCondition(Expression<Func<T, bool>> condition)
        {
            return _dataSet.Where(condition);
        }

        public virtual void Update(T entity)
        {
            _dataSet.Update(entity);
            SaveChanges();
        }
        public virtual void SaveChanges()
        {
            _dbContext.SaveChanges();
        }

        public void AddRange(List<T> list)
        {
            _dbContext.AddRange(list);
        }
    }
}
