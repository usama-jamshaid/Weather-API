﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace Weather.Models
{
    public class PaginatedRequest
    {
        public int Start { get; set; }
        public int Count { get; set; }
    }
    public class GetWeatherRequest : PaginatedRequest
    {
        public string Location { get; set; }
        public bool IsOpenWeather { get; set; }
    }
   
    public class PaginatedResponse
    {

    }

    public class ResponseBase
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public static ResponseBase GetSuccess(string msg = "Operation performed successfully")
        {
            return new ResponseBase
            {
                Success = true,
                Message = msg
            };
        }
        public static ResponseBase GetFailure(string msg = "Unable to perform the specified operation")
        {
            return new ResponseBase
            {
                Success = false,
                Message = msg
            };
        }

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
    public class ResponseModel<T> : ResponseBase
    {     
        public T Data { get; set; }
    
        public static ResponseModel<T> GetSuccess(T data, string msg = "Operation performed successfully")
        {
            return new ResponseModel<T>
            {
                Success = true,
                Data = data,
                Message = msg
            };
        }
        public static ResponseModel<T> GetFailure(string msg = "Unable to perform the specified operation")
        {
            return new ResponseModel<T>
            {
                Success = false,
                Message = msg
            };
        }
    }
}
