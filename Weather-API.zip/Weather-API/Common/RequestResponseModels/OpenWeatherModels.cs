﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common.RequestResponseModels
{
    public class OWGetCoordinatesResponse
    {
        public string name { get; set; }
        public double lat { get; set; }
        public double lon { get; set; }
    }
    public class OWForecastResponse
    {
        public List[] list { get; set; }
    }
    public class List
    {
        public int dt { get; set; }
        public Main main { get; set; }
        public Weather[] weather { get; set; }
    }
    public class Main
    {
        public float temp { get; set; }
    }
    public class Weather
    {
        public string icon { get; set; }
    }
}
