﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace Weather.Abstractions
{
    //Base service class with some major CRUDs operation
    public interface IBaseService<T>
    {
        T Get(int Id);
        IQueryable<T> GetByCondition(Expression<Func<T, bool>> condition);
        void Update(T entity);
        void Delete(int id);
        void Add(T entity);
        void AddRange(List<T> list);
        void SaveChanges();
    }
}
