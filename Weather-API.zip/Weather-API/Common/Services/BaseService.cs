﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using Weather.Abstractions;
using Weather.Models;

namespace Weather.Services
{
    public class BaseService<T> : IBaseService<T> where T : BaseEntity
    {
        private readonly IBaseRepository<T> _baseRepository;
        public BaseService(IBaseRepository<T> baseRepository)
        {
            _baseRepository = baseRepository;
        }
        public void Add(T entity)
        {
            _baseRepository.Add(entity);
        }

        public void AddRange(List<T> list)
        {
            _baseRepository.AddRange(list);
            SaveChanges();
        }

        public void Delete(int id)
        {
            _baseRepository.Delete(id);
        }

        public T Get(int Id)
        {
            return _baseRepository.Get(Id);
        }

        public IQueryable<T> GetByCondition(Expression<Func<T, bool>> condition)
        {
            return _baseRepository.GetByCondition(condition);
        }

        public void SaveChanges()
        {
            _baseRepository.SaveChanges();
        }

        public void Update(T entity)
        {
            _baseRepository.Update(entity);
        }
    }
}
